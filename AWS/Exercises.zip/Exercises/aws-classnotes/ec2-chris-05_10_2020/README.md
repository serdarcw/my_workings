http -> port 80
https -> port 443

urls translated to ip address by DNS servers

www.bbc.com -> 12.15.23.5 by DNS server